import styles from "./RectangleComponent.module.css";

const RectangleComponent = () => {
  return (
    <div className={styles.rectangleParent} id="overallStatus">
      <div className={styles.componentChild} id="OverallStatusContainer" />
      <div className={styles.ofStudiesParent}>
        <span className={styles.ofStudies} id="NoOfStudiesLabel">
          # of Studies
        </span>
        <h4 className={styles.h4} id="NoOfStudiesValue">
          60
        </h4>
      </div>
      <div className={styles.ofProgramsParent}>
        <span className={styles.ofStudies} id="NoofProgramLabel">
          # of Programs
        </span>
        <h4 className={styles.m} id="NoOfProgramValue">
          10
        </h4>
      </div>
      <div className={styles.costsParent}>
        <span className={styles.ofStudies} id="costLabel">
          Costs
        </span>
        <h4 className={styles.m} id="costValue">
          $260M
        </h4>
      </div>
      <h2 className={styles.overallStatus} id="OverallStatusTitle">
        Overall Status
      </h2>
      <div className={styles.componentItem} />
    </div>
  );
};

export default RectangleComponent;

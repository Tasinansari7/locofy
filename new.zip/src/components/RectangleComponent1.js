import styles from "./RectangleComponent1.module.css";

const RectangleComponent1 = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.componentChild} id="DemandSource" />
      <div className={styles.datasource1Parent}>
        <span
          className={styles.datasource1}
          id="DataSource1Label"
        >{`DataSource 1 `}</span>
        <h4 className={styles.h4} id="dataSource1Value">
          10%
        </h4>
      </div>
      <div className={styles.datasource2Parent}>
        <span className={styles.datasource1} id="dataSource2Label">
          DataSource 2
        </span>
        <h4 className={styles.h4} id="dataSource2Value">
          90%
        </h4>
      </div>
      <div className={styles.yearPlanningHorizon}>
        (5 Year Planning Horizon)
      </div>
      <b className={styles.demandSourceContainer}>
        <p className={styles.demandSource}>Demand Source  </p>
      </b>
      <img className={styles.vectorIcon} alt="" src="/vector@2x.png" />
    </div>
  );
};

export default RectangleComponent1;

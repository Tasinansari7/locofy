import styles from "./RectangleComponent2.module.css";

const RectangleComponent2 = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.componentChild} id="BudgetStatus" />
      <div className={styles.approvedParent}>
        <span className={styles.approved} id="ApprovedLabel">
          Approved
        </span>
        <h4 className={styles.h4} id="ApprovedValue">
          110
        </h4>
      </div>
      <div className={styles.plannedParent}>
        <span className={styles.approved} id="plannedLabel">
          Planned
        </span>
        <h4 className={styles.h4} id="plannedValue">
          88
        </h4>
      </div>
      <div className={styles.fundedParent}>
        <span className={styles.approved} id="fundedLabel">
          Funded
        </span>
        <h4 className={styles.h4} id="fundedValue">
          62
        </h4>
      </div>
      <div className={styles.yearPlanningHorizon}>
        (5 Year Planning Horizon)
      </div>
      <b className={styles.budgetStatus}>{`Budget Status `}</b>
      <img className={styles.vectorIcon} alt="" src="/vector@2x.png" />
    </div>
  );
};

export default RectangleComponent2;

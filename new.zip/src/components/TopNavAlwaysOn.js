import { useMemo } from "react";
import styles from "./TopNavAlwaysOn.module.css";

const TopNavAlwaysOn = ({
  iconImageUrl,
  appTitle,
  nullText,
  showGroupDiv,
  topNavAlwaysOnPosition,
  topNavAlwaysOnTop,
  topNavAlwaysOnLeft,
  topNavAlwaysOnBackgroundColor,
  groupDivColor,
}) => {
  const topNavAlwaysOnStyle = useMemo(() => {
    return {
      position: topNavAlwaysOnPosition,
      top: topNavAlwaysOnTop,
      left: topNavAlwaysOnLeft,
    };
  }, [topNavAlwaysOnPosition, topNavAlwaysOnTop, topNavAlwaysOnLeft]);

  const topNavAlwaysOn1Style = useMemo(() => {
    return {
      backgroundColor: topNavAlwaysOnBackgroundColor,
    };
  }, [topNavAlwaysOnBackgroundColor]);

  const groupIconStyle = useMemo(() => {
    return {
      color: groupDivColor,
    };
  }, [groupDivColor]);

  return (
    <div className={styles.topNavalwaysOn} style={topNavAlwaysOnStyle}>
      <div className={styles.groupParent}>
        <div className={styles.groupParent}>
          <div className={styles.groupParent}>
            <div className={styles.desktopHeaderChild} />
            <img
              className={styles.desktopHeaderItem}
              alt=""
              src="/group-1183@2x.png"
            />
            <b className={styles.nampAnalytics}>NAMP Analytics</b>
            <div className={styles.welcomeBackSteven}>
              Welcome back, Steven Ishwar
            </div>
          </div>
          <img
            className={styles.logoAmgen1Icon}
            alt=""
            src="/logoamgen-1@2x.png"
          />
        </div>
        <div className={styles.alwaysOnParent}>
          <b className={styles.alwaysOn}>Always On</b>
          <div className={styles.nampLrcParent}>
            <b className={styles.nampLrc}>NAMP LRC</b>
            <div className={styles.groupChild} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopNavAlwaysOn;

import RectangleComponent2 from "../components/RectangleComponent2";
import RectangleComponent1 from "../components/RectangleComponent1";
import RectangleComponent from "../components/RectangleComponent";
import TopNavAlwaysOn from "../components/TopNavAlwaysOn";
import styles from "./Frame.module.css";

const Frame = () => {
  return (
    <div className={styles.componentParent}>
      <RectangleComponent2 />
      <RectangleComponent1 />
      <div className={styles.rectangleParent}>
        <div className={styles.groupChild} />
        <b className={styles.createLrc}>{`2022 Q1 NAMP Estimate `}</b>
        <b className={styles.may32022}>May 3, 2022</b>
        <div className={styles.mslDate}>MSL Date:</div>
        <img className={styles.vectorIcon} alt="" src="/vector@2x.png" />
      </div>
      <RectangleComponent />
      <TopNavAlwaysOn
        iconImageUrl="/group-1183@2x.png"
        appTitle="Budget Tracker"
        showGroupDiv={false}
        topNavAlwaysOnPosition="absolute"
        topNavAlwaysOnTop="0px"
        topNavAlwaysOnLeft="0px"
        topNavAlwaysOnBackgroundColor="unset"
        groupDivColor="transparent"
      />
    </div>
  );
};

export default Frame;
